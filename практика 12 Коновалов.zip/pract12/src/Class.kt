import sun.net.www.ApplicationLaunchException

open class ClassFun {
    fun input():Int
    {
        try {
            print("Введите сколько раз вы хотите выполнить функцию: ")
            var chislo= readLine()!!.toInt()
            if (chislo>0)
                return chislo
            else println("Ошибка, число не может быть меньше нуля или нулем")
        }
        catch (e:Exception) {
            ("Вы ввели недопустимые значения")
        }
        return 1
    }

    fun ZamenaChisel()
    {
        try
        {
            print("Введите число А: ")
            var a= readLine()!!.toInt()
            if (a<0)
            {
                println("Вы ввели недопустимое число для A")
            }
            print("Введите число B: ")
            var b= readLine()!!.toInt()
            if (b<0)
            {
                println("Вы ввели недопустимое число для B")

            }
            print("Введите число C: ")
            var c= readLine()!!.toInt()
            if (c<0)
            {
                println("Вы ввели недопустимое число для C")

            }
            if (a<0 && b<0 && c<0)
            {
                println("Вы ввели недопустимые числа для переменных А B C")
            }
            else {
                println("Число A стало = $c")
                println("Число B стало = $a")
                println("Число C стало = $b")
            }
        }
        catch (e:Exception) {
            println("Вы ввели недопустимые значения")
        }
    }
}

