import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.GlobalScope

suspend fun main()
{
     var nameClass:ClassFun = ClassFun()
    var K=nameClass.input()
    GlobalScope.launch {
        for (i in 1..K) {

            println("$i запуск ")
            nameClass.ZamenaChisel()
        }
    }
    runBlocking { delay(15000L) }
}

